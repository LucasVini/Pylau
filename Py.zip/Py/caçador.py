# coding=utf-8
import sys
import time
import gc


from PyQt5.QtCore import QThread
from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox, QTableWidgetItem, QDialog
from SearchDeviceUI import Ui_MainWindow
from InitDevAccountUI import Ui_InitDevAccount
from queue import Queue

from NetSDK.NetSDK import NetClient
from NetSDK.SDK_Enum import *
from NetSDK.SDK_Struct import *
from NetSDK.SDK_Callback import fSearchDevicesCBEx, fSearchDevicesCB
from ctypes import *

import socket
import struct

global wnd
device_queue = Queue(maxsize=0)
nUpdateNum = 0

## INIT
# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'InitDevAccountUI.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_InitDevAccount(object):
    def setupUi(self, InitDevAccount):
        InitDevAccount.setObjectName("InitDevAccount")
        InitDevAccount.resize(407, 275)
        self.username_lineEdit = QtWidgets.QLineEdit(InitDevAccount)
        self.username_lineEdit.setGeometry(QtCore.QRect(260, 40, 113, 20))
        self.username_lineEdit.setObjectName("username_lineEdit")
        self.username_label = QtWidgets.QLabel(InitDevAccount)
        self.username_label.setGeometry(QtCore.QRect(150, 40, 101, 20))
        self.username_label.setObjectName("username_label")
        self.confirm_password_label = QtWidgets.QLabel(InitDevAccount)
        self.confirm_password_label.setGeometry(QtCore.QRect(90, 130, 161, 20))
        self.confirm_password_label.setObjectName("confirm_password_label")
        self.way_lineEdit = QtWidgets.QLineEdit(InitDevAccount)
        self.way_lineEdit.setEnabled(False)
        self.way_lineEdit.setGeometry(QtCore.QRect(160, 170, 91, 20))
        self.way_lineEdit.setObjectName("way_lineEdit")
        self.confirm_password_lineEdit = QtWidgets.QLineEdit(InitDevAccount)
        self.confirm_password_lineEdit.setGeometry(QtCore.QRect(260, 130, 113, 20))
        self.confirm_password_lineEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.confirm_password_lineEdit.setObjectName("confirm_password_lineEdit")
        self.reset_way_lineEdit = QtWidgets.QLineEdit(InitDevAccount)
        self.reset_way_lineEdit.setGeometry(QtCore.QRect(260, 170, 113, 20))
        self.reset_way_lineEdit.setObjectName("reset_way_lineEdit")
        self.reser_way_label = QtWidgets.QLabel(InitDevAccount)
        self.reser_way_label.setGeometry(QtCore.QRect(40, 170, 121, 20))
        self.reser_way_label.setObjectName("reser_way_label")
        self.password_lineEdit = QtWidgets.QLineEdit(InitDevAccount)
        self.password_lineEdit.setGeometry(QtCore.QRect(260, 80, 113, 20))
        self.password_lineEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.password_lineEdit.setObjectName("password_lineEdit")
        self.password_label = QtWidgets.QLabel(InitDevAccount)
        self.password_label.setGeometry(QtCore.QRect(160, 80, 91, 20))
        self.password_label.setObjectName("password_label")
        self.pushButton = QtWidgets.QPushButton(InitDevAccount)
        self.pushButton.setGeometry(QtCore.QRect(150, 210, 121, 31))
        self.pushButton.setObjectName("pushButton")

        self.retranslateUi(InitDevAccount)
        self.pushButton.clicked.connect(InitDevAccount.accept)
        QtCore.QMetaObject.connectSlotsByName(InitDevAccount)

    def retranslateUi(self, InitDevAccount):
        _translate = QtCore.QCoreApplication.translate
        InitDevAccount.setWindowTitle(_translate("InitDevAccount", "(Initialization)"))
        self.username_label.setText(_translate("InitDevAccount", "(Username)"))
        self.confirm_password_label.setText(_translate("InitDevAccount", "(Confirm Password)"))
        self.reser_way_label.setText(_translate("InitDevAccount", "(Reset Way)"))
        self.password_label.setText(_translate("InitDevAccount", "(Password)"))
        self.pushButton.setText(_translate("InitDevAccount", "(OK)"))

##UI
# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SearchDeviceUI.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(677, 702)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.devicelist_groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.devicelist_groupBox.setGeometry(QtCore.QRect(20, 10, 641, 381))
        self.devicelist_groupBox.setObjectName("devicelist_groupBox")
        self.tableWidget = QtWidgets.QTableWidget(self.devicelist_groupBox)
        self.tableWidget.setEnabled(True)
        self.tableWidget.setGeometry(QtCore.QRect(30, 20, 601, 351))
        self.tableWidget.setGridStyle(QtCore.Qt.SolidLine)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(11)
        self.tableWidget.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        font = QtGui.QFont()
        font.setPointSize(9)
        item.setFont(font)
        self.tableWidget.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(5, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(6, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(7, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(8, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(9, item)
        item = QtWidgets.QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(10, item)
        self.tableWidget.horizontalHeader().setDefaultSectionSize(150)
        self.tableWidget.horizontalHeader().setMinimumSectionSize(50)
        self.tableWidget.verticalHeader().setVisible(False)
        self.searchdevice_groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.searchdevice_groupBox.setGeometry(QtCore.QRect(20, 400, 311, 141))
        self.searchdevice_groupBox.setObjectName("searchdevice_groupBox")
        self.SearchDeviceButton = QtWidgets.QPushButton(self.searchdevice_groupBox)
        self.SearchDeviceButton.setEnabled(True)
        self.SearchDeviceButton.setGeometry(QtCore.QRect(30, 50, 261, 41))
        self.SearchDeviceButton.setObjectName("SearchDeviceButton")
        self.Searchtime_label = QtWidgets.QLabel(self.centralwidget)
        self.Searchtime_label.setGeometry(QtCore.QRect(360, 450, 121, 20))
        self.Searchtime_label.setObjectName("Searchtime_label")
        self.Searchtime_lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.Searchtime_lineEdit.setGeometry(QtCore.QRect(490, 450, 131, 20))
        self.Searchtime_lineEdit.setObjectName("Searchtime_lineEdit")
        self.Init_groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.Init_groupBox.setGeometry(QtCore.QRect(20, 540, 311, 91))
        self.Init_groupBox.setObjectName("Init_groupBox")
        self.InitButton = QtWidgets.QPushButton(self.Init_groupBox)
        self.InitButton.setGeometry(QtCore.QRect(30, 30, 261, 41))
        self.InitButton.setObjectName("InitButton")
        self.SearchByIpButton = QtWidgets.QPushButton(self.centralwidget)
        self.SearchByIpButton.setGeometry(QtCore.QRect(360, 570, 261, 41))
        self.SearchByIpButton.setObjectName("SearchByIpButton")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(340, 400, 331, 231))
        self.groupBox.setObjectName("groupBox")
        self.StartIP_lineEdit = QtWidgets.QLineEdit(self.groupBox)
        self.StartIP_lineEdit.setGeometry(QtCore.QRect(150, 90, 131, 20))
        self.StartIP_lineEdit.setObjectName("StartIP_lineEdit")
        self.StartIP_label = QtWidgets.QLabel(self.groupBox)
        self.StartIP_label.setGeometry(QtCore.QRect(20, 90, 121, 20))
        self.StartIP_label.setObjectName("StartIP_label")
        self.label_2 = QtWidgets.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(30, 130, 111, 20))
        self.label_2.setObjectName("label_2")
        self.EndIP_lineEdit = QtWidgets.QLineEdit(self.groupBox)
        self.EndIP_lineEdit.setGeometry(QtCore.QRect(150, 130, 131, 20))
        self.EndIP_lineEdit.setObjectName("EndIP_lineEdit")
        self.groupBox.raise_()
        self.searchdevice_groupBox.raise_()
        self.devicelist_groupBox.raise_()
        self.Searchtime_label.raise_()
        self.Searchtime_lineEdit.raise_()
        self.Init_groupBox.raise_()
        self.SearchByIpButton.raise_()
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 677, 23))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.SearchDeviceButton.clicked.connect(MainWindow.search_Device_Btn)
        self.InitButton.clicked.connect(MainWindow.Init_Btn)
        self.SearchByIpButton.clicked.connect(MainWindow.search_Device_ByIp_Btn)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Search Devices"))
        self.devicelist_groupBox.setTitle(_translate("MainWindow", "(Device List)"))
        item = self.tableWidget.horizontalHeaderItem(0)
        item.setText(_translate("MainWindow", "(No.)"))
        item = self.tableWidget.horizontalHeaderItem(1)
        item.setText(_translate("MainWindow", "(Status)"))
        item = self.tableWidget.horizontalHeaderItem(2)
        item.setText(_translate("MainWindow", "(IP Version)"))
        item = self.tableWidget.horizontalHeaderItem(3)
        item.setText(_translate("MainWindow", "(IP Address)"))
        item = self.tableWidget.horizontalHeaderItem(4)
        item.setText(_translate("MainWindow", "(Port)"))
        item = self.tableWidget.horizontalHeaderItem(5)
        item.setText(_translate("MainWindow", " (Subnet Mask)"))
        item = self.tableWidget.horizontalHeaderItem(6)
        item.setText(_translate("MainWindow", "(Gateway)"))
        item = self.tableWidget.horizontalHeaderItem(7)
        item.setText(_translate("MainWindow", "(Mac Address)"))
        item = self.tableWidget.horizontalHeaderItem(8)
        item.setText(_translate("MainWindow", "(Device Type)"))
        item = self.tableWidget.horizontalHeaderItem(9)
        item.setText(_translate("MainWindow", "(Detail Type)"))
        item = self.tableWidget.horizontalHeaderItem(10)
        item.setText(_translate("MainWindow", "Http(Http)"))
        self.searchdevice_groupBox.setTitle(_translate("MainWindow", "(Search Devices)"))
        self.SearchDeviceButton.setText(_translate("MainWindow", "(Multicast and Broadcast)"))
        self.Searchtime_label.setText(_translate("MainWindow", "(Time:ms):"))
        self.Searchtime_lineEdit.setText(_translate("MainWindow", "3000"))
        self.Init_groupBox.setTitle(_translate("MainWindow", "(Operate Devices)"))
        self.InitButton.setText(_translate("MainWindow", "(Initialization)"))
        self.SearchByIpButton.setText(_translate("MainWindow", "点对点搜索(Point to Point Search)"))
        self.groupBox.setTitle(_translate("MainWindow", "(Unicast)"))
        self.StartIP_label.setText(_translate("MainWindow", "(Start IP)"))
        self.label_2.setText(_translate("MainWindow", "(End IP)"))





class Mythread(QThread):


    def __init__(self, parent=None):
        super().__init__(parent)


    def run(self):
        global nUpdateNum
        while not device_queue.empty():
           wnd.update_UItable(device_queue.get())
           device_queue.task_done()
           nUpdateNum += 1
           if(nUpdateNum % 10 == 0):
               wnd.tableWidget.update()
               wnd.tableWidget.viewport().update()
               nUpdateNum = 0
               time.sleep(0.1)




@CB_FUNCTYPE(None, C_LLONG, POINTER(DEVICE_NET_INFO_EX2), c_void_p)
def search_device_callback(lSearchHandle, pDevNetInfo, pUserData):
    try:
        buf = cast(pDevNetInfo, POINTER(DEVICE_NET_INFO_EX2)).contents
        print("Enter in search_device_callback")
        if(buf.stuDevInfo.iIPVersion == 4):
            device_queue.put(list((buf.stuDevInfo.byInitStatus, buf.stuDevInfo.iIPVersion, buf.stuDevInfo.szIP, buf.stuDevInfo.nPort, buf.stuDevInfo.szSubmask, buf.stuDevInfo.szGateway,
                               buf.stuDevInfo.szMac, buf.stuDevInfo.szDeviceType, buf.stuDevInfo.szDetailType, buf.stuDevInfo.nHttpPort, buf.stuDevInfo.byPwdResetWay, buf.szLocalIP)))
        wnd.thread.run()
    except Exception as e:
        print(e)

@CB_FUNCTYPE(None, POINTER(DEVICE_NET_INFO_EX), c_void_p)
def search_devie_byIp_callback(pDevNetInfo, pUserData):
    try:
        buf = cast(pDevNetInfo, POINTER(DEVICE_NET_INFO_EX)).contents
        print("Enter in search_devie_byIp_callback")
        if (buf.iIPVersion == 4):
            device_queue.put(list((buf.byInitStatus,buf.iIPVersion, buf.szIP, buf.nPort, buf.szSubmask, buf.szGateway, buf.szMac, buf.szDeviceType, buf.szDetailType, buf.nHttpPort, buf.byPwdResetWay, None)))
        wnd.thread.run()
    except Exception as e:
        print(e)

class MyMainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)
        self.setupUi(self)
        self.init_ui()

        self.sdk = NetClient()
        self.sdk.InitEx(None, 0)

        self.thread = Mythread()
        self.thread.start()


    def init_ui(self):
        nUpdateNum = 0
        self.row = 0
        self.column = 0
        self.device_info_list = []
        self.device_mac_list = []
        self.lSearchHandle_list = []
        self.SearchDeviceButton.setEnabled(True)

    # ip
    def getIPAddrs(self):
        ip_list = socket.gethostbyname_ex(socket.gethostname())
        for ips in ip_list:
            if type(ips) == list and len(ips) != 0:
                IPlist = ips[0:]
        del ip_list
        return IPlist


    def start_search_device(self):

        IPList = self.getIPAddrs()
        nSuccess = 0
        for i in range(IPList.__len__()):
            startsearch_in = NET_IN_STARTSERACH_DEVICE()
            startsearch_in.dwSize = sizeof(NET_IN_STARTSERACH_DEVICE)
            startsearch_in.emSendType = EM_SEND_SEARCH_TYPE.MULTICAST_AND_BROADCAST
            startsearch_in.cbSearchDevices = search_device_callback
            startsearch_in.szLocalIp = IPList[i].encode()
            startsearch_out = NET_OUT_STARTSERACH_DEVICE()
            startsearch_out.dwSize = sizeof(NET_OUT_STARTSERACH_DEVICE)
            lSearchHandle = self.sdk.StartSearchDevicesEx(startsearch_in, startsearch_out)
            if lSearchHandle != 0:
                nSuccess += 1
                self.lSearchHandle_list.append(lSearchHandle)
        if(IPList.__len__() > 0):
            del IPList
        if(nSuccess > 0):
            return True
        else:
            return False


    def start_search_device_byIP(self, start_IP, end_IP): 
        startsearchbyIp_in = DEVICE_IP_SEARCH_INFO()
        startsearchbyIp_in.dwSize = sizeof(DEVICE_IP_SEARCH_INFO)
        start = struct.unpack("!I", socket.inet_aton(start_IP))[0] 
        end = struct.unpack("!I", socket.inet_aton(end_IP))[0]
        if (end - start > 255):
            QMessageBox.about(self, '(prompt)', "IP 256(Number of IP addresses exceeds the upper limit 256.)")
            return False

        startsearchbyIp_in.nIpNum = end - start + 1

        for i in range(startsearchbyIp_in.nIpNum):
            ip = DEVICE_IP_SEARCH_INFO_IP()
            ip.IP = socket.inet_ntoa(struct.pack("!I", start + i)).encode()
            startsearchbyIp_in.szIP[i] = ip

        wait_time = int(wnd.Searchtime_lineEdit.text())

        IPList = self.getIPAddrs()
        nSuccessNum = 0
        for i in range(IPList.__len__()):
            result = self.sdk.SearchDevicesByIPs(startsearchbyIp_in, search_devie_byIp_callback, 0, IPList[i].encode(), wait_time)
            if result:
                nSuccessNum =+ 1
        if (IPList.__len__() > 0):
            del IPList
        if(nSuccessNum > 0):
            return True
        else:
            return False



    def stop_search_device(self):
        for i in range(self.lSearchHandle_list.__len__()):
            result = self.sdk.StopSearchDevices(self.lSearchHandle_list[i])
        nUpdateNum = 0
        self.lSearchHandle_list.clear()
        self.device_info_list.clear()
        self.device_mac_list.clear()
        self.tableWidget.clear()
        self.row = 0
        self.column = 0
        device_queue.queue.clear()
        if(not device_queue.empty()):
            device_queue.task_done()
        self.tableWidget.setHorizontalHeaderLabels(['序号(No.)', '状态(Status)', 'IP版本(IP Version)', 'IP地址(IP Address)', '端口(Port)', '子网掩码(Subnet Mask)', '网关(Gateway)', '物理地址(Mac Address)', '设备类型(Device Type)', '详细类型(Detail Type)', 'Http(Http)'])
        return


    def check_ip(self, ipaddr):
        addr = ipaddr.split('.')  
        if len(addr) != 4:  
            del addr
            return False

        for i in range(4):
            try:
                addr[i] = int(addr[i])  
            except:
                del addr
                return False

            if addr[i] <= 255 and addr[i] >= 0:  
                pass
            else:
                del addr
                return False
        del addr
        gc.collect()
        return True


    def init_device_accout(self, device_info:list):
        child = QDialog()
        child_ui = Ui_InitDevAccount()
        child_ui.setupUi(child)
        if (1 == (device_info[3] & 1)):

            child_ui.way_lineEdit.setText('(Phone)')
        elif (1 == (device_info[3] >> 1 & 1)):

            child_ui.way_lineEdit.setText('(Mail)')
        value = child.exec()
        if (value == 0):
            return False
        init_Account_In = NET_IN_INIT_DEVICE_ACCOUNT()
        init_Account_In.dwSize = sizeof(init_Account_In)
        init_Account_In.szMac = device_info[2]
        username = child_ui.username_lineEdit.text()
        password = child_ui.password_lineEdit.text()
        confirm_password = child_ui.confirm_password_lineEdit.text()
        if(password != confirm_password):
            QMessageBox.about(self, '(prompt)', "(Confirm password is wrong，please input again)")
            return
        init_Account_In.szUserName = username.encode()
        init_Account_In.szPwd = password.encode()
        init_Account_In.szCellPhone = child_ui.reset_way_lineEdit.text().encode()
        if (1 == (device_info[3] & 1)):

            init_Account_In.szCellPhone = child_ui.reset_way_lineEdit.text().encode()
        elif(1 == (device_info[3] >> 1 & 1)):

            init_Account_In.szMail = child_ui.reset_way_lineEdit.text().encode()
        init_Account_In.byPwdResetWay = device_info[3]
        init_Account_Out = NET_OUT_INIT_DEVICE_ACCOUNT()
        init_Account_Out.dwSize = sizeof(init_Account_Out)

        result = self.sdk.InitDevAccount(init_Account_In, init_Account_Out, 5000, device_info[4])
        if result:
            return True
        else:
            QMessageBox.about(self, '提示(prompt)', 'error:' + str(self.sdk.GetLastError()))
            return False



    def search_Device_Btn(self):
        self.stop_search_device()
        result = self.start_search_device()

    def search_Device_ByIp_Btn(self):
        self.stop_search_device()
        self.tableWidget.setHorizontalHeaderLabels(['序号(No.)', '状态(Status)', 'IP版本(IP Version)', 'IP地址(IP Address)', '端口(Port)', '子网掩码(Subnet Mask)', '网关(Gateway)', '物理地址(Mac Address)', '设备类型(Device Type)', '详细类型(Detail Type)', 'Http(Http)'])
        start_IP = self.StartIP_lineEdit.text()
        end_IP = self.EndIP_lineEdit.text()
        if(start_IP != '') and (end_IP != ''):
            if (self.check_ip(start_IP) == True)and (self.check_ip(end_IP)== True):
                result = self.start_search_device_byIP(start_IP, end_IP)
            else:
                QMessageBox.about(self, '提示(prompt)', "IP不正确(IP is wrong)")
                pass
        else:
            QMessageBox.about(self, '提示(prompt)', "IP不能为空(IP can not be empty)")
            pass

    def Init_Btn(self):

        currentRow = self.tableWidget.currentRow()
        if((len(self.device_info_list) ==0)or((self.device_info_list[currentRow][0]&3) != 1)):
            QMessageBox.about(self, '提示(prompt)', "请选择未初始化设备(Please select not initialized device)")
        else:
            result = self.init_device_accout(self.device_info_list[currentRow])
            if result == True:
                QMessageBox.about(self, '提示(prompt)', "初始化成功(Initialize Success)")
                item = QTableWidgetItem("已初始化(Initialize)")
                self.device_info_list[currentRow][0] = 2
                self.tableWidget.setItem(currentRow, 1, item)
                self.tableWidget.update()
                self.tableWidget.viewport().update()



    def update_UItable(self, device_list):

        if device_list[6] in self.device_mac_list:
            return
        if device_list[1] != 4:
            return
        self.device_mac_list.append(device_list[6])
        self.device_info_list.append(list((device_list[0], device_list[2],device_list[6], device_list[10], device_list[11])))
        self.tableWidget.setRowCount(self.row + 1)
        item = QTableWidgetItem(str(self.row + 1))
        self.tableWidget.setItem(self.row, self.column, item)
        if ((device_list[0] & 3) == 1):
            item1 = QTableWidgetItem("未初始化(Uninitialize)")
            self.tableWidget.setItem(self.row, self.column + 1, item1)
        else:
            item1 = QTableWidgetItem("已初始化(Initialize)")
            self.tableWidget.setItem(self.row, self.column + 1, item1)
        item2 = QTableWidgetItem(str(device_list[1]))
        self.tableWidget.setItem(self.row, self.column + 2, item2)
        item3 = QTableWidgetItem(str(device_list[2].decode()))
        self.tableWidget.setItem(self.row, self.column + 3, item3)
        item4 = QTableWidgetItem(str(device_list[3]))
        self.tableWidget.setItem(self.row, self.column + 4, item4)
        item5 = QTableWidgetItem(str(device_list[4].decode()))
        self.tableWidget.setItem(self.row, self.column + 5, item5)
        item6 = QTableWidgetItem(str(device_list[5].decode()))
        self.tableWidget.setItem(self.row, self.column + 6, item6)
        item7 = QTableWidgetItem(str(device_list[6].decode()))
        self.tableWidget.setItem(self.row, self.column + 7, item7)
        item8 = QTableWidgetItem(str(device_list[7].decode()))
        self.tableWidget.setItem(self.row, self.column + 8, item8)
        item9 = QTableWidgetItem(str(device_list[8].decode()))
        self.tableWidget.setItem(self.row, self.column + 9, item9)
        item10 = QTableWidgetItem(str(device_list[9]))
        self.tableWidget.setItem(self.row, self.column + 10, item10)

        self.row += 1
        #table
        device_list.clear()
        del device_list




    def closeEvent(self, event):
        event.accept()
        print('exit')
        self.stop_search_device()
        self.sdk.Cleanup()
        del self.lSearchHandle_list
        del self.device_info_list
        del self.device_mac_list

if __name__ == '__main__':
    app = QApplication(sys.argv)
    my_wnd = MyMainWindow()
    wnd = my_wnd
    my_wnd.show()
    app.processEvents()
    sys.exit(app.exec_())

