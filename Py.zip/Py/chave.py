# Autor: Lucas Vinicius de Oliveira
# Gerador de chave RSA para autenticação de servidor-cliente SFTP

import paramiko

def gerar_chave():
    private_key = paramiko.RSAKey.generate(2048)
    private_key.write_private_key_file('server_key.pem')
    print("Chave privada gerada e salva como 'server_key.pem'.")

if __name__ == "__main__":
    gerar_chave()