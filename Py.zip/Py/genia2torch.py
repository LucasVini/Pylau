import torch
from transformers import pipeline

# Usar a GPU se disponível, senão a CPU
device = 0 if torch.cuda.is_available() else -1

# Carregar o modelo e tokenizer
model = pipeline("text-generation", model="google/gemma-2-2b-it", device=device)

def chat_with_model(user_input):
    # Gerar a resposta com controles de temperatura e top_p para evitar repetições e garantir mais coerência
    response = model(
        user_input, 
        max_new_tokens=50,   # Limitar o número de tokens gerados
        temperature=0.7,     # Controla a aleatoriedade (0.7 é um valor comum)
        top_p=0.9,           # Usa amostragem nucleus para limitar os tokens mais prováveis
        truncation=True      # Ativa truncamento para entradas muito longas
    )
    return response[0]['generated_text']

def main():
    print("Bem-vindo ao chat com o modelo Qwen2.5-0.5B!")
    
    while True:
        user_input = input("Você: ")
        
        if user_input.lower() == "sair":
            print("Até logo!")
            break
        
        response = chat_with_model(user_input)
        print(f"Qwen2.5-0.5B: {response}")

if __name__ == "__main__":
    main()
