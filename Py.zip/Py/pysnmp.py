from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton
from pysnmp import *

class SNMPApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Consulta SNMP")

        # Layout
        layout = QVBoxLayout()

        # Entradas
        self.ip_input = QLineEdit(self)
        self.ip_input.setPlaceholderText("IP do DVR/NVR")
        self.port_input = QLineEdit(self)
        self.port_input.setPlaceholderText("Porta (padrão: 161)")
        self.community_input = QLineEdit(self)
        self.community_input.setPlaceholderText("Comunidade SNMP (ex.: public)")
        self.oid_input = QLineEdit(self)
        self.oid_input.setPlaceholderText("OID (ex.: 1.3.6.1.2.1.1.1.0)")

        # Botão de consulta
        self.query_button = QPushButton("Consultar SNMP", self)
        self.query_button.clicked.connect(self.consultar_snmp)

        # Resultado
        self.result_label = QLabel("Resultado aparecerá aqui...", self)

        # Adiciona os widgets ao layout
        layout.addWidget(self.ip_input)
        layout.addWidget(self.port_input)
        layout.addWidget(self.community_input)
        layout.addWidget(self.oid_input)
        layout.addWidget(self.query_button)
        layout.addWidget(self.result_label)

        self.setLayout(layout)

    def consultar_snmp(self):
        from pysnmp.hlapi import SnmpEngine, CommunityData, UdpTransportTarget, ContextData, ObjectType, ObjectIdentity, getCmd

        # Obtém dados da interface
        ip = self.ip_input.text()
        port = int(self.port_input.text())
        community = self.community_input.text()
        oid = self.oid_input.text()

        # Consulta SNMP
        try:
            iterator = getCmd(
                SnmpEngine(),
                CommunityData(community),
                UdpTransportTarget((ip, port)),
                ContextData(),
                ObjectType(ObjectIdentity(oid))
            )
            errorIndication, errorStatus, errorIndex, varBinds = next(iterator)

            if errorIndication:
                self.result_label.setText(f"Erro SNMP: {errorIndication}")
            elif errorStatus:
                self.result_label.setText(f"Erro no status: {errorStatus.prettyPrint()}")
            else:
                resultado = "\n".join([f"{varBind[0]} = {varBind[1]}" for varBind in varBinds])
                self.result_label.setText(resultado)

        except Exception as e:
            self.result_label.setText(f"Erro: {e}")

# Executa o aplicativo
if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = SNMPApp()
    window.show()
    sys.exit(app.exec_())
