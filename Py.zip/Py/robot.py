from robot import run
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def execute_robot_tests(search_term):
    try:
        # Create a temporary .robot file with the test content
        robot_code = f"""
*** Settings ***
Library    SeleniumLibrary

*** Test Cases ***
Pesquisar no Google
    Abrir o navegador
    Aceitar Cookies (se necessário)
    Pesquisar "{search_term}"
    Fechar o navegador

*** Keywords ***
Abrir o navegador
    Open Browser    https://www.google.com    chrome
    Maximize Browser Window

Aceitar Cookies (se necessário)
    ${{cookies_button}}=    Run Keyword And Return Status    Element Should Be Visible    xpath=//div[contains(text(),'Aceitar')]
    Run Keyword If    ${{cookies_button}}    Click Element    xpath=//div[contains(text(),'Aceitar')]

Pesquisar
    [Arguments]    ${{termo}}
    Input Text    name=q    ${{termo}}
    Press Keys    name=q    ENTER
    Wait Until Page Contains    Resultados da Web

Fechar o navegador
    Close Browser
        """

        with open("temp_google_search.robot", "w") as f:
            f.write(robot_code)

        # Execute the Robot Framework test
        result = run("temp_google_search.robot", outputdir='resultados', report='relatorio.html', log='log.html')

        # Remove the temporary file
        os.remove("temp_google_search.robot")

        return result

    except Exception as e:
        print(f"Erro ao executar testes Robot: {e}")
        return 1

if __name__ == "__main__":
    search_term = "python"
    return_code = execute_robot_tests(search_term)
    if return_code == 0:
        print("Teste executado com sucesso!")
    else:
        print(f"A execução falhou com código: {return_code}")