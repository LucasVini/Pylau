from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time


# Inicialize o navegador
driver = webdriver.Chrome()
driver.get("http://10.100.22.125")

## ACESSO NO GRAVADOR
try:
    # Acessa o campo de usuário e insere o texto
    username_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, "ant-input"))
    )
    username_input.send_keys("admin")

        # Localiza o campo de senha pelo placeholder "Senha"
    password_input = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, "input[placeholder='Senha']"))
    )
    password_input.send_keys("adminadmin12345")


    # Envia o formulário de login (ajuste o seletor conforme necessário)
    submit_button = driver.find_element(By.CLASS_NAME, "login-button")
    submit_button.click()

    #PADRÃO DE FAB
    # Aguarde o login e adicione uma espera para "Configurações"
    try:
        configuracoes = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//span[text()='Configurações']"))
        )
        configuracoes.click()
        time.sleep(2)
        
            # Depois, localize e clique em "Sistema"
        reset = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//span[text()='Sistema']"))
        )
        reset.click()

            # Após clicar em "Sistema" e "Padrão"
        reset_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//a[@href='#/index/SysConfig/defaultConfig']"))
        )
        reset_link.click()

                    # Aguarda o botão "Padrão de fábrica" ficar clicável e, em seguida, clica nele
        padrao_fabrica_botao = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//div[contains(@class, 'labelText-wrapper') and text()='Padrão de fábrica']"))
        )
        padrao_fabrica_botao.click()

                # Aguarda o botão "OK" ficar clicável e clica nele
        ok_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(@class, 'ant-btn-primary') and span[text()='OK']]"))
        )
        ok_button.click()

        password_field = driver.find_element(By.XPATH, "//input[@class='ant-input false' and @placeholder='Senha']")
        password_field.send_keys("adminadmin12345")

                # Localiza e clica no botão "OK"
        ok_button = driver.find_element(By.XPATH, "//div[@class='labelText-wrapper labelText undefined' and text()='OK']")
        ok_button.click()



    except Exception as e:
        print("Ocorreu um erro:", e)



    """   #RTMP
        # Aguarde o login e adicione uma espera para "Configurações"
        try:
            configuracoes = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//span[text()='Configurações']"))
            )
            configuracoes.click()
            time.sleep(2)
            
            # Depois, localize e clique em "Rede"
            rede = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//span[text()='Rede']"))
            )
            rede.click()

            # Após clicar em "Rede", aguarde e clique em "RTMP"
            rtmp_link = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='#/index/NetWork/RTMP']"))
            )
            rtmp_link.click()

        except Exception as e:
            print("Ocorreu um erro:", e)
    """
except Exception as e:
    print(f"Ocorreu um erro: {e}")
finally:
    #driver.quit()
    input("Pressione Enter para sair")
