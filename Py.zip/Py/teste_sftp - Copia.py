import socket
import paramiko
from paramiko import SFTPServerInterface, SFTPServer, ServerInterface, AUTH_SUCCESSFUL, RSAKey

# Configurações do host e porta
HOST = '0.0.0.0'
PORT = 3373

# Credenciais de autenticação
USERNAME = 'user'
PASSWORD = 'senha'

class MySFTPServer(SFTPServerInterface):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    # Implementação de métodos do SFTPServerInterface, se necessário

class SimpleServer(ServerInterface):
    def check_auth_password(self, username, password):
        if (username == USERNAME) and (password == PASSWORD):
            return AUTH_SUCCESSFUL
        else:
            return paramiko.AUTH_FAILED

    def get_allowed_auths(self, username):
        return 'password'

class SFTPServerHandler:
    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.server_key = RSAKey.generate(2048)

    def serve_forever(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind((self.host, self.port))
        sock.listen(100)

        print(f"Servidor SFTP rodando em {self.host}:{self.port}")

        while True:
            client, addr = sock.accept()
            print(f"Conexão de {addr}")

            transport = paramiko.Transport(client)
            transport.add_server_key(self.server_key)

            server = SimpleServer()
            try:
                transport.start_server(server=server)
            except paramiko.SSHException as e:
                print(f"Erro ao iniciar servidor SSH: {e}")
                client.close()
                continue

            chan = transport.accept(timeout=20)
            if chan is None:
                print("Erro ao abrir o canal ou timeout")
                continue

            try:
                sftp_server = MySFTPServer()
                sftp = paramiko.SFTPServer(chan, sftp_server)
                print("Cliente autenticado e canal SFTP aberto")
            except Exception as e:
                print(f"Erro ao iniciar SFTP: {e}")
            finally:
                chan.close()

if __name__ == "__main__":
    server = SFTPServerHandler(HOST, PORT)
    server.serve_forever()
