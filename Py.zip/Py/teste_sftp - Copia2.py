import os
import paramiko
import socket
import threading

# Diretório onde os arquivos recebidos serão armazenados
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RECEIVED_DIR = os.path.join(BASE_DIR, 'SFTP_RECEBIDO')

# Cria o diretório para os arquivos recebidos se não existir
if not os.path.exists(RECEIVED_DIR):
    os.makedirs(RECEIVED_DIR)

class SFTPServer(paramiko.ServerInterface):
    def __init__(self):
        self.event = threading.Event()
        self.event.set()

    def check_channel_request(self, kind, chanid):
        if kind == 'session':
            return paramiko.OPEN_SUCCEEDED
        return paramiko.SSH_EXCEPTION

    def check_channel_shell_request(self, channel):
        return paramiko.OPEN_SUCCEEDED

    def check_channel_exec_request(self, channel, command):
        return paramiko.OPEN_SUCCEEDED

    def check_channel_subsystem_request(self, channel, subsystem):
        return paramiko.OPEN_SUCCEEDED

    def check_auth_password(self, username, password):
        # Permite qualquer login e senha para simplicidade
        return paramiko.AUTH_SUCCESSFUL

class SFTPHandler(paramiko.SFTPServerInterface):
    def __init__(self, server):
        self.server = server

    def list_folder(self, path):
        full_path = os.path.join(RECEIVED_DIR, path.lstrip('/'))
        return [paramiko.SFTPAttributes.from_stat(os.stat(os.path.join(full_path, f))) for f in os.listdir(full_path)]
    
    def open(self, path, mode):
        full_path = os.path.join(RECEIVED_DIR, path.lstrip('/'))
        return open(full_path, mode)

    def remove(self, path):
        os.remove(os.path.join(RECEIVED_DIR, path.lstrip('/')))

    def rename(self, oldpath, newpath):
        os.rename(os.path.join(RECEIVED_DIR, oldpath.lstrip('/')), os.path.join(RECEIVED_DIR, newpath.lstrip('/')))

    def mkdir(self, path, mode):
        os.makedirs(os.path.join(RECEIVED_DIR, path.lstrip('/')))

    def rmdir(self, path):
        os.rmdir(os.path.join(RECEIVED_DIR, path.lstrip('/')))

    def chattr(self, path, attrs):
        pass  # No-op for simplicity

def handle_client(transport):
    try:
        server = paramiko.SFTPServer(transport, SFTPHandler)
        server.serve_forever()
    except Exception as e:
        print(f'Erro ao manipular cliente: {e}')
    finally:
        transport.close()

def start_sftp_server(host, port):
    try:
        # Cria o socket e inicia o servidor
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind((host, port))
        sock.listen(1)
        print(f'Servidor SFTP rodando em {host}:{port}')

        while True:
            client_socket, addr = sock.accept()
            transport = paramiko.Transport(client_socket)
            transport.add_server_key(paramiko.RSAKey.generate(2048))
            server = SFTPServer()
            transport.start_server(server=server)

            threading.Thread(target=handle_client, args=(transport,)).start()
    except Exception as e:
        print(f'Erro ao iniciar o servidor SFTP: {e}')

if __name__ == '__main__':
    host = '0.0.0.0'  # Usar o IP local da máquina
    port = 3373
    start_sftp_server(host, port)
