# coding=utf-8
import os
import sys

from PyQt5.QtWidgets import QApplication, QMainWindow, QMessageBox
from PyQt5.QtCore import Qt, QDateTime
from ctypes import *

from NetSDK.NetSDK import NetClient
from NetSDK.SDK_Callback import fDisConnect, fHaveReConnect
from NetSDK.SDK_Enum import EM_DEV_CFG_TYPE, EM_LOGIN_SPAC_CAP_TYPE
from NetSDK.SDK_Struct import (
    LOG_SET_PRINT_INFO,
    NET_TIME,
    C_LDWORD,
    C_LLONG,
    NET_IN_LOGIN_WITH_HIGHLEVEL_SECURITY,
    NET_OUT_LOGIN_WITH_HIGHLEVEL_SECURITY,
    CB_FUNCTYPE,
)

from PyQt5 import QtCore, QtGui, QtWidgets


### importando definições dos elementos visuais


class Ui_MainWindow_time(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(589, 307)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.groupBox = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox.setGeometry(QtCore.QRect(10, 10, 561, 101))
        self.groupBox.setObjectName("groupBox")
        self.label = QtWidgets.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(20, 30, 71, 16))
        self.label.setObjectName("label")
        self.IP_lineEdit = QtWidgets.QLineEdit(self.groupBox)
        self.IP_lineEdit.setGeometry(QtCore.QRect(90, 30, 121, 20))
        self.IP_lineEdit.setObjectName("IP_lineEdit")
        self.label_2 = QtWidgets.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(240, 30, 71, 16))
        self.label_2.setObjectName("label_2")
        self.Port_lineEdit = QtWidgets.QLineEdit(self.groupBox)
        self.Port_lineEdit.setGeometry(QtCore.QRect(310, 30, 113, 20))
        self.Port_lineEdit.setObjectName("Port_lineEdit")
        self.label_3 = QtWidgets.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(10, 70, 71, 16))
        self.label_3.setObjectName("label_3")
        self.Name_lineEdit = QtWidgets.QLineEdit(self.groupBox)
        self.Name_lineEdit.setGeometry(QtCore.QRect(90, 70, 121, 20))
        self.Name_lineEdit.setObjectName("Name_lineEdit")
        self.label_4 = QtWidgets.QLabel(self.groupBox)
        self.label_4.setGeometry(QtCore.QRect(240, 70, 101, 16))
        self.label_4.setObjectName("label_4")
        self.Pwd_lineEdit = QtWidgets.QLineEdit(self.groupBox)
        self.Pwd_lineEdit.setGeometry(QtCore.QRect(310, 70, 113, 20))
        self.Pwd_lineEdit.setEchoMode(QtWidgets.QLineEdit.Password)
        self.Pwd_lineEdit.setObjectName("Pwd_lineEdit")
        self.Login_pushButton = QtWidgets.QPushButton(self.groupBox)
        self.Login_pushButton.setGeometry(QtCore.QRect(460, 30, 91, 31))
        self.Login_pushButton.setObjectName("Login_pushButton")
        self.groupBox_2 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox_2.setGeometry(QtCore.QRect(10, 200, 571, 61))
        self.groupBox_2.setObjectName("groupBox_2")
        self.GetTime_pushButton = QtWidgets.QPushButton(self.groupBox_2)
        self.GetTime_pushButton.setGeometry(QtCore.QRect(330, 30, 75, 23))
        self.GetTime_pushButton.setObjectName("GetTime_pushButton")
        self.SetTime_pushButton = QtWidgets.QPushButton(self.groupBox_2)
        self.SetTime_pushButton.setGeometry(QtCore.QRect(430, 30, 75, 23))
        self.SetTime_pushButton.setObjectName("SetTime_pushButton")
        self.Time_dateTimeEdit = QtWidgets.QDateTimeEdit(self.groupBox_2)
        self.Time_dateTimeEdit.setGeometry(QtCore.QRect(90, 30, 191, 22))
        self.Time_dateTimeEdit.setDateTime(
            QtCore.QDateTime(QtCore.QDate(1, 1, 0), QtCore.QTime(0, 0, 0))
        )
        self.Time_dateTimeEdit.setObjectName("Time_dateTimeEdit")
        self.label_5 = QtWidgets.QLabel(self.groupBox_2)
        self.label_5.setGeometry(QtCore.QRect(20, 30, 71, 16))
        self.label_5.setObjectName("label_5")
        self.groupBox_3 = QtWidgets.QGroupBox(self.centralwidget)
        self.groupBox_3.setGeometry(QtCore.QRect(370, 120, 211, 71))
        self.groupBox_3.setObjectName("groupBox_3")



        
        
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 589, 255))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "🕒Sincronizador de Horário"))
        self.groupBox.setTitle(_translate("MainWindow", "Login no dispositivo"))
        self.label.setText(_translate("MainWindow", "🌎IP"))
        self.label_2.setText(_translate("MainWindow", "Porta"))
        self.label_3.setText(_translate("MainWindow", "🚹Usuário"))
        self.label_4.setText(_translate("MainWindow", "🔐Senha"))
        self.Login_pushButton.setText(_translate("MainWindow", "Login"))
        self.groupBox_2.setTitle(_translate("MainWindow", "Calibrar Temporizador"))
        self.GetTime_pushButton.setText(_translate("MainWindow", "get"))
        self.SetTime_pushButton.setText(_translate("MainWindow", "set"))
        self.Time_dateTimeEdit.setDisplayFormat(
            _translate("MainWindow", "dd/MM/yyyy HH:mm:ss")
        )
        self.label_5.setText(_translate("MainWindow", "Tempo"))

### criando classes e funções de acordo:

file = "d:/log.log"


@CB_FUNCTYPE(c_int, c_char_p, c_uint, C_LDWORD)
def SDKLogCallBack(szLogBuffer, nLogSize, dwUser):
    try:
        with open(file, "a") as f:
            f.write(szLogBuffer.decode())
    except Exception as e:
        print(e)
    return 1


class MyMainWindow(QMainWindow, Ui_MainWindow_time):
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)
        self.setupUi(self)

        # 界面初始化
        self._init_ui()

        # NetSDK用到的相关变量和回调
        self.loginID = C_LLONG()
        self.m_DisConnectCallBack = fDisConnect(self.DisConnectCallBack)
        self.m_ReConnectCallBack = fHaveReConnect(self.ReConnectCallBack)

        # 获取NetSDK对象并初始化
        self.sdk = NetClient()
        self.sdk.InitEx(self.m_DisConnectCallBack)
        self.sdk.SetAutoReconnect(self.m_ReConnectCallBack)

    # 初始化界面
    def _init_ui(self):
        self.Login_pushButton.setText("Entrar")

        self.IP_lineEdit.setText("10.100.")
        self.Port_lineEdit.setText("37777")
        self.Name_lineEdit.setText("admin")
        self.Pwd_lineEdit.setText("")

        self.setWindowFlag(Qt.WindowMinimizeButtonHint)
        self.setWindowFlag(Qt.WindowCloseButtonHint)
        self.setFixedSize(self.width(), self.height())

        self.Login_pushButton.clicked.connect(self.login_btn_onclick)
        
        
        self.GetTime_pushButton.clicked.connect(self.gettime_btn_onclick)
        self.SetTime_pushButton.clicked.connect(self.settime_btn_onclick)


    def login_btn_onclick(self):
        if not self.loginID:
            ip = self.IP_lineEdit.text()
            port = int(self.Port_lineEdit.text())
            username = self.Name_lineEdit.text()
            password = self.Pwd_lineEdit.text()
            stuInParam = NET_IN_LOGIN_WITH_HIGHLEVEL_SECURITY()
            stuInParam.dwSize = sizeof(NET_IN_LOGIN_WITH_HIGHLEVEL_SECURITY)
            stuInParam.szIP = ip.encode()
            stuInParam.nPort = port
            stuInParam.szUserName = username.encode()
            stuInParam.szPassword = password.encode()
            stuInParam.emSpecCap = EM_LOGIN_SPAC_CAP_TYPE.TCP
            stuInParam.pCapParam = None

            stuOutParam = NET_OUT_LOGIN_WITH_HIGHLEVEL_SECURITY()
            stuOutParam.dwSize = sizeof(NET_OUT_LOGIN_WITH_HIGHLEVEL_SECURITY)

            self.loginID, device_info, error_msg = self.sdk.LoginWithHighLevelSecurity(
                stuInParam, stuOutParam
            )
            if self.loginID != 0:
                self.setWindowTitle("(DeviceControl)-(OnLine)")
                self.Login_pushButton.setText("(Logout)")
            else:
                print("não pode estar vázio")
        else:
            result = self.sdk.Logout(self.loginID)
            if result:
                self.setWindowTitle("(DeviceControl)-(OffLine)")
                self.Login_pushButton.setText("(Login)")
                self.loginID = 0

    def openlog_btn_onclick(self):
        log_info = LOG_SET_PRINT_INFO()
        log_info.dwSize = sizeof(LOG_SET_PRINT_INFO)
        log_info.bSetFilePath = 1
        log_info.szLogFilePath = os.path.join(os.getcwd(), "sdk_log.log").encode("gbk")
        log_info.cbSDKLogCallBack = SDKLogCallBack
        result = self.sdk.LogOpen(log_info)
        if not result:
            QMessageBox.about(self, "(prompt)", self.sdk.GetLastErrorMessage())

    def closelog_btn_onclick(self):
        result = self.sdk.LogClose()
        if not result:
            QMessageBox.about(self, "(prompt)", self.sdk.GetLastErrorMessage())

    def gettime_btn_onclick(self):
        time = NET_TIME()
        result = self.sdk.GetDevConfig(
            self.loginID, int(EM_DEV_CFG_TYPE.TIMECFG), -1, time, sizeof(NET_TIME)
        )
        if not result:
            QMessageBox.about(self, "(prompt)", self.sdk.GetLastErrorMessage())
        else:
            get_time = QDateTime(
                time.dwYear,
                time.dwMonth,
                time.dwDay,
                time.dwHour,
                time.dwMinute,
                time.dwSecond,
            )
            self.Time_dateTimeEdit.setDateTime(get_time)

    def settime_btn_onclick(self):
        device_date = self.Time_dateTimeEdit.date()
        device_time = self.Time_dateTimeEdit.time()
        deviceDateTime = NET_TIME()
        deviceDateTime.dwYear = device_date.year()
        deviceDateTime.dwMonth = device_date.month()
        deviceDateTime.dwDay = device_date.day()
        deviceDateTime.dwHour = device_time.hour()
        deviceDateTime.dwMinute = device_time.minute()
        deviceDateTime.dwSecond = device_time.second()

        result = self.sdk.SetDevConfig(
            self.loginID,
            int(EM_DEV_CFG_TYPE.TIMECFG),
            -1,
            deviceDateTime,
            sizeof(NET_TIME),
        )
        if not result:
            QMessageBox.about(self, "(prompt)", self.sdk.GetLastErrorMessage())

    def restart_btn_onclick(self):
        result = self.sdk.RebootDev(self.loginID)
        if not result:
            QMessageBox.about(self, "(prompt)", self.sdk.GetLastErrorMessage())
        else:
            QMessageBox.about(self, "(prompt)", "(restart succeed)")

    def DisConnectCallBack(self, lLoginID, pchDVRIP, nDVRPort, dwUser):
        self.setWindowTitle("Offline")

    def ReConnectCallBack(self, lLoginID, pchDVRIP, nDVRPort, dwUser):
        self.setWindowTitle("Online")

    def closeEvent(self, event):
        event.accept()
        if self.loginID:
            self.sdk.Logout(self.loginID)
        self.sdk.Cleanup()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    my_wnd = MyMainWindow()
    wnd = my_wnd
    my_wnd.show()
    sys.exit(app.exec_())
